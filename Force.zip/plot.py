#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

# =========================
# SETTINGS
# =========================
DATA_DIR = Path(".")  # folder with the txt files

FILES = {
    0.5: ["0.5.txt"],
    1.0: ["1.txt"],
    2.5: ["2.5.txt"],
    3.0: ["3.txt"],
    3.5: ["3.5txt", "3.5.txt"],  # accept both names
}

G = 9.80665  # m/s^2

# Choose calibration method:
#   "linear"  -> piecewise linear interpolation (no SciPy)
#   "pchip"   -> smooth monotonic interpolation (requires SciPy)
#   "poly"    -> polynomial fit (explicit formula)
CAL_METHOD = "pchip"
POLY_DEG = 2  # used only if CAL_METHOD="poly"

# Optional: subtract "zero" offset (if you have a file with 0kg you can add it)
USE_TARE = False
TARE_VALUE = 0.0  # or set to your measured ADC at 0 force


# =========================
# IO
# =========================
def read_adc_file(path: Path) -> np.ndarray:
    vals = []
    for line in path.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            vals.append(float(line))
        except ValueError:
            pass
    arr = np.array(vals, dtype=float)
    if USE_TARE:
        arr = arr - TARE_VALUE
    return arr


def load_all():
    data = {}
    for mass, candidates in FILES.items():
        chosen = None
        for name in candidates:
            p = DATA_DIR / name
            if p.exists():
                chosen = p
                break
        if chosen is None:
            raise FileNotFoundError(f"Missing file for {mass} kg. Tried {candidates} in {DATA_DIR.resolve()}")
        arr = read_adc_file(chosen)
        if arr.size == 0:
            raise ValueError(f"{chosen} has no numeric samples.")
        data[mass] = arr
    return data


# =========================
# CALIBRATION (ADC -> N)
# =========================
def make_calibrator(adc_means, force_N, method="linear", poly_deg=2):
    # sort by ADC (must be increasing for interpolation)
    order = np.argsort(adc_means)
    x = np.asarray(adc_means)[order]
    y = np.asarray(force_N)[order]

    if method == "linear":
        def f(adc):
            return float(np.interp(adc, x, y, left=y[0], right=y[-1]))
        return f, {"method": "linear", "x": x, "y": y}

    if method == "pchip":
        try:
            from scipy.interpolate import PchipInterpolator
            interp = PchipInterpolator(x, y, extrapolate=True)
            def f(adc):
                return float(interp(adc))
            return f, {"method": "pchip", "x": x, "y": y}
        except Exception as e:
            print("SciPy not found / PCHIP failed -> fallback to linear.")
            def f(adc):
                return float(np.interp(adc, x, y, left=y[0], right=y[-1]))
            return f, {"method": "linear_fallback", "x": x, "y": y, "error": str(e)}

    if method == "poly":
        coeff = np.polyfit(x, y, deg=poly_deg)  # y = poly(x)
        def f(adc):
            return float(np.polyval(coeff, adc))
        return f, {"method": "poly", "deg": poly_deg, "coeff": coeff, "x": x, "y": y}

    raise ValueError("Unknown method. Use: linear, pchip, poly")


# =========================
# MAIN
# =========================
def main():
    data = load_all()

    masses = np.array(sorted(data.keys()), dtype=float)
    forces_N = masses * G

    adc_means = np.array([np.mean(data[m]) for m in masses])
    adc_stds  = np.array([np.std(data[m], ddof=1) if data[m].size > 1 else 0.0 for m in masses])
    adc_mins  = np.array([np.min(data[m]) for m in masses])
    adc_maxs  = np.array([np.max(data[m]) for m in masses])

    print("\n=== Sensor stats (ADC) ===")
    for m, mu, sd, mn, mx in zip(masses, adc_means, adc_stds, adc_mins, adc_maxs):
        print(f"{m:>4.1f} kg: mean={mu:9.2f}  std={sd:7.2f}  min={mn:9.0f}  max={mx:9.0f}  n={data[m].size}")

    # -------- Plot 1: distribution per mass --------
    plt.figure()
    plt.boxplot([data[m] for m in masses], labels=[str(m) for m in masses], showfliers=False)
    plt.xlabel("Mass (kg)")
    plt.ylabel("ADC counts")
    plt.title("Force sensor output distribution per mass")
    plt.grid(True, alpha=0.3)

    # -------- Plot 2: mean ± std vs mass --------
    plt.figure()
    plt.errorbar(masses, adc_means, yerr=adc_stds, fmt="o-", capsize=4)
    plt.xlabel("Mass (kg)")
    plt.ylabel("ADC mean ± std")
    plt.title("Sensor mean output vs mass")
    plt.grid(True, alpha=0.3)

    # -------- Build calibration: ADC -> N --------
    adc_to_N, info = make_calibrator(adc_means, forces_N, method=CAL_METHOD, poly_deg=POLY_DEG)
    print("\n=== Calibration ===")
    print("Method:", info["method"])
    if info["method"] == "poly":
        print("Polynomial coeff (highest power first):", info["coeff"])

    # -------- Plot 3: Force(N) vs ADC with fit --------
    plt.figure()
    plt.plot(adc_means, forces_N, "o", label="Calibration points (means)")

    adc_grid = np.linspace(min(adc_means) * 0.98, max(adc_means) * 1.02, 500)
    force_fit = np.array([adc_to_N(a) for a in adc_grid])
    plt.plot(adc_grid, force_fit, "-", label=f"Fit ({info['method']})")

    plt.xlabel("ADC mean")
    plt.ylabel("Force (N)")
    plt.title("Nonlinearity + approximation (ADC -> Force)")
    plt.grid(True, alpha=0.3)
    plt.legend()

    # -------- Plot 4: residuals at points --------
    pred = np.array([adc_to_N(a) for a in adc_means])
    resid = pred - forces_N

    plt.figure()
    plt.axhline(0, linewidth=1)
    plt.plot(masses, resid, "o-")
    plt.xlabel("Mass (kg)")
    plt.ylabel("Residual (pred - true) [N]")
    plt.title("Calibration residuals")
    plt.grid(True, alpha=0.3)

    # -------- Print "linearization" mapping for use --------
    # This is what you use in code: ADC -> Newton
    print("\n=== Ready mapping (ADC -> Newton) ===")
    if info["method"] in ("linear", "linear_fallback", "pchip"):
        x = info["x"].tolist()
        y = info["y"].tolist()
        print("Use piecewise points (ADC_POINTS, F_POINTS_N).")
        print("ADC_POINTS =", x)
        print("F_POINTS_N =", y)
        print("\nFunction (no SciPy needed):")
        print("def adc_to_newton(adc: float) -> float:")
        print("    import numpy as np")
        print("    ADC_POINTS =", x)
        print("    F_POINTS_N =", y)
        print("    return float(np.interp(adc, ADC_POINTS, F_POINTS_N, left=F_POINTS_N[0], right=F_POINTS_N[-1]))")
    else:
        coeff = info["coeff"].tolist()
        print("Polynomial mapping:")
        print("POLY_COEFF =", coeff)
        print("def adc_to_newton(adc: float) -> float:")
        print("    import numpy as np")
        print("    POLY_COEFF =", coeff)
        print("    return float(np.polyval(POLY_COEFF, adc))")

    plt.show()


if __name__ == "__main__":
    main()